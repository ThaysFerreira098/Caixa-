package com.info;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CaixaApplicationTests {

	@Test
	void contextLoads() {
	}

}
